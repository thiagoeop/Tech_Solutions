import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Cpu, Wrench, Settings, TrendingUp, ArrowRight } from "lucide-react";
import { useNavigate } from "react-router-dom";
import heroImage from "@/assets/hero-tech.jpg";

const Index = () => {
  const navigate = useNavigate();

  const services = [
    {
      icon: Cpu,
      title: "Montagem de PCs",
      description: "Montagem personalizada com as melhores peças do mercado"
    },
    {
      icon: Wrench,
      title: "Manutenção",
      description: "Manutenção preventiva e corretiva de computadores e notebooks"
    },
    {
      icon: Settings,
      title: "Upgrade",
      description: "Upgrade de hardware para melhor desempenho do seu equipamento"
    },
    {
      icon: TrendingUp,
      title: "Consultoria",
      description: "Consultoria técnica para escolha ideal de componentes"
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{ backgroundImage: `url(${heroImage})` }}
        >
          <div className="absolute inset-0 bg-background/80 backdrop-blur-sm"></div>
        </div>
        
        <div className="relative z-10 container mx-auto px-4 text-center space-y-8 animate-fade-in">
          <h1 className="text-5xl md:text-7xl font-bold">
            <span className="bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent">
              TechService Pro
            </span>
          </h1>
          <p className="text-xl md:text-2xl text-foreground max-w-3xl mx-auto">
            Montagem e Manutenção de Computadores e Notebooks com Tecnologia de Ponta
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button 
              size="lg" 
              onClick={() => navigate("/dashboard")}
              className="bg-primary hover:bg-primary/90 text-primary-foreground shadow-tech text-lg px-8 py-6 transition-all hover:shadow-tech/70 hover:scale-105"
            >
              Acessar Sistema
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
            <Button 
              size="lg" 
              variant="outline"
              className="border-2 border-secondary text-secondary hover:bg-secondary/10 text-lg px-8 py-6 transition-all hover:scale-105"
            >
              Nossos Serviços
            </Button>
          </div>
        </div>

        <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-background to-transparent"></div>
      </section>

      {/* Services Section */}
      <section className="py-24 container mx-auto px-4">
        <div className="text-center mb-16 space-y-4 animate-fade-in">
          <h2 className="text-4xl md:text-5xl font-bold text-primary">Nossos Serviços</h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Soluções completas em tecnologia para seu negócio ou uso pessoal
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service, index) => (
            <Card 
              key={index} 
              className="border-border bg-card shadow-card hover:shadow-tech transition-all duration-300 hover:scale-105 animate-scale-in"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <CardHeader>
                <div className="w-12 h-12 rounded-lg bg-gradient-tech flex items-center justify-center mb-4">
                  <service.icon className="h-6 w-6 text-primary" />
                </div>
                <CardTitle className="text-xl">{service.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-base">{service.description}</CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-tech opacity-10"></div>
        <div className="container mx-auto px-4 text-center relative z-10 space-y-8">
          <h2 className="text-4xl md:text-5xl font-bold">
            Pronto para começar?
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Acesse nosso sistema de gestão e comece a organizar seu negócio agora mesmo
          </p>
          <Button 
            size="lg"
            onClick={() => navigate("/dashboard")}
            className="bg-primary hover:bg-primary/90 text-primary-foreground shadow-tech text-lg px-8 py-6 transition-all hover:shadow-tech/70 hover:scale-105"
          >
            Acessar Dashboard
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-8">
        <div className="container mx-auto px-4 text-center text-muted-foreground">
          <p>&copy; 2025 TechService Pro. Todos os direitos reservados.</p>
        </div>
      </footer>
    </div>
  );
};

export default Index;
